make
./bin/esi-escape